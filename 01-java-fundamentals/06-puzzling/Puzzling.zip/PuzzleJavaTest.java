public class PuzzleJavaTest {
    public static void main(String[] args){
        PuzzleJava pj = new PuzzleJava();

    pj.arrNumbers();
    pj.arrNames();
    pj.arrAlphabet();
    pj.arrRandom();
    pj.arrRandom2();

    }
    
}
