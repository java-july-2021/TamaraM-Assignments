public class PythagoreanTest {
    public static void main(String[] args){
        Pythagorean result = new Pythagorean();
        double hypotenuse = result.calculateHypotenuse(2,10);
        System.out.println("The value of hypotenuse is: " + hypotenuse);
    }
}
