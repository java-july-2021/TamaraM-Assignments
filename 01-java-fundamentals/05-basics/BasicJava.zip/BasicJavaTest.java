import java.util.Arrays;
public class BasicJavaTest {
    
    public static void main(String[] args){
        BasicJava bj = new BasicJava();
        
        bj.printNumbers();
        
        bj.printOddNumbers();

        bj.printSum(); 
        
        bj.array();

        bj.findMax();

        bj.average();

        bj.oddNumbers();
        
        bj.greaterThanY();

        bj.square();

        //Max,Min, Average
        int[] x ={8,13,-27,0,2,15, 125,2};
        System.out.println(Arrays.toString(bj.maxMinAvg(x)));
            
            
        //Eliminate Negative
        int[] arr = {1,5,10,-2};    
        System.out.println(Arrays.toString(bj.eliminate(arr)));
        
        //Shifting the Values in the Array
        int[] arr1 = {1,5,10,7,-2}; 
        System.out.println(Arrays.toString(bj.shiftValues(arr1)));
    }
}    
    
    
